# Flying Bird

This is a game on Android made by the Future Animation & Game Team at Tsinghua University.

The development environment is gamemaker 1.



This source is used for version control of the code between the developers in the team. All the images resources are not included in.



To develop and run, download this project and manually put in the folders `sprites/` and `background/` that includes all the images needed, then open `/FlyingBird.project.gmx` by gamemaker 1.

